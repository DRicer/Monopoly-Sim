

class Turn():
	
	def TakeTurn(self, player, api):
		