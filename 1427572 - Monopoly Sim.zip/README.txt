coded using Python 3
run "python rules.py" in cmd at root to begin simulator